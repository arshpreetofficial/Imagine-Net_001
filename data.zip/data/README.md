# Data Preparation Guide

This project uses the ADNI, CLAS, and AIBL datasets for training and evaluation.

## Dataset Access

- **ADNI**: https://adni.loni.usc.edu
- **CLAS**: https://github.com/Jae-Han/CLAS-dataset
- **AIBL**: https://aibl.csiro.au

You must register and agree to their data usage terms.

